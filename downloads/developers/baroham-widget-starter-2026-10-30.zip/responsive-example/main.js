const widget = {
  render(api) {
    const c = api.canvas, r = api.contentRect;
    if (api.settings.theme) api.useThemeBackground?.();
    const scale = Math.min(api.width / 480, api.height / 320);
    const gap = 12 * scale, columns = api.width >= api.height ? 2 : 1;
    const rows = 2 / columns, w = (r.width - gap * (columns + 1)) / columns;
    const h = (r.height - gap * (rows + 1)) / rows;
    const cards = [0, 1].map(i => ({x:r.x+gap+(i%columns)*(w+gap), y:r.y+gap+Math.floor(i/columns)*(h+gap)}));
    const state = api.state; state.counts = state.counts || [0, 0];
    if (api.active) for (const tap of api.inputs || []) {
      if (tap.sequence <= (state.sequence || 0)) continue;
      state.sequence = tap.sequence;
      cards.forEach((card, i) => {if(tap.x>=card.x && tap.x<card.x+w && tap.y>=card.y && tap.y<card.y+h) state.counts[i]=(state.counts[i]+1)%10000;});
    }
    cards.forEach((card, i) => {
      c.fillStyle = '#122D34'; c.beginPath(); c.roundRect(card.x,card.y,w,h,12*scale); c.fill();
      c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#E8F6F2'; c.font = (16*scale)+'px sans-serif';
      c.fillText(i===0 ? api.width+' × '+api.height : api.t('tap','Tap the card'),card.x+w/2,card.y+h*.25);
      c.fillStyle = '#86E9C6'; c.font = '600 '+(36*scale)+'px sans-serif'; c.fillText(String(state.counts[i]),card.x+w/2,card.y+h*.58);
    });
  }
};
