# Responsive Baroham / 반응형 예제

Requires the updated Studio with `viewport: 1` support. The published 0.9.40
release does not have this capability; older hosts reject this ZIP safely.
This is a separate optional example, not a replacement for Hello.

Resize a Mac/Windows virtual screen: landscape uses two columns, portrait two
rows. Each card counts taps. Layout is recalculated on every render; state is
memory-only. `api.contentRect` excludes host navigation. Input coordinates use
exactly the same coordinate system as drawings and may be fractional.

현재 업데이트된 맥·윈도우 가상 화면에서 크기·비율을 따라 배치됩니다.
기존 ESP32·안드로이드 연결에서는 480×320 호환 좌표로 동작합니다.
이 기능은 기기 프로토콜이나 이미지 전송 해상도를 변경하지 않습니다.
기존 hello-example과 기존 위젯의 좌표·설정은 바뀌지 않습니다.
