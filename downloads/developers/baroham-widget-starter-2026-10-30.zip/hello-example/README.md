# Hello Baroham

Studio 0.9.40+ 권장. 예제 ZIP을 전체화면 → 위젯 관리에 넣고 사용을 켭니다.
미리보기는 카운트를 바꾸지 않습니다. 기기에서 지금 보기를 누르고 카드를 터치하세요.
카운트는 메모리에만 유지되며 앱 재시작·패키지 교체·캐시 퇴출 시 초기화됩니다.

Recommended: Studio 0.9.40+. Drop the ZIP into Fullscreen → Manage widgets,
enable it, and choose Show on device. Tap the card on a device or the virtual
fullscreen. Passive previews do not increment the count. State is memory-only.

To customize, change the ID for a new widget, edit main.js/settings.json,
and increment version for every changed ZIP. ZIP the contents of this folder,
not the folder itself. No npm, Python, device firmware or internet is required
for running the installed widget. Source example: MIT, see LICENSE.txt.
