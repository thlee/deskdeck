const widget = {
  render(api) {
    const c = api.canvas;
    if (api.settings.theme) api.useThemeBackground?.();
    const state = api.state;
    state.count = Number.isInteger(state.count) ? state.count : 0;
    state.lastSequence = state.lastSequence || 0;
    if (api.active) {
      for (const tap of api.inputs || []) {
        if (tap.sequence <= state.lastSequence) continue;
        state.lastSequence = tap.sequence;
        if (tap.x >= 32 && tap.x < 448 && tap.y >= 72 && tap.y < 264) {
          state.count = (state.count + 1) % 10000;
        }
      }
    }
    c.fillStyle = '#122D34';
    c.beginPath(); c.roundRect(32, 72, 416, 192, 20); c.fill();
    c.textAlign = 'center'; c.fillStyle = '#E8F6F2';
    c.font = '20px sans-serif';
    const message = String(api.settings.message);
    c.fillText(message.length > 26 ? message.slice(0, 25) + '…' : message, 240, 112);
    c.fillStyle = '#86E9C6'; c.font = '600 64px sans-serif';
    c.fillText(String(state.count), 240, 192);
    c.fillStyle = '#C0D6D5'; c.font = '18px sans-serif';
    c.fillText(api.t('tap', 'Tap the card'), 240, 235);
  }
};
