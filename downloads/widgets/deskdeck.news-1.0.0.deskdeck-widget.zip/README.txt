DeskDeck News 1.0.0

Optional external widget: drop this ZIP onto Studio > Fullscreen > Manage widgets.
Requires the news-package-capable Studio build; the public 0.8.18 release does not support it.
ESP32 and Android updates are not required.

The package supplies its layout and default feeds. Studio supplies RSS/Atom retrieval,
settings and tap-to-open browser actions. This is a declarative package, with no scripts.
Right-click to export/delete. Deletion removes installed feed settings.

Default feed: NASA news releases (English)
https://www.nasa.gov/news-release/feed/
https://www.nasa.gov/rss-feeds/
https://www.nasa.gov/nasa-brand-center/images-and-media/

Only headlines, source, publication time and original links are displayed.
No article text or photographs are displayed. NASA does not endorse DeskDeck.
Check each provider's terms before adding other feeds.
Contact: deskdeck.app@gmail.com
