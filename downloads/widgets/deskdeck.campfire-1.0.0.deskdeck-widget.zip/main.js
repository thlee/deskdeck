/* Heat propagation adapted from Filipe Deschamps' doom-fire-algorithm (MIT).
 * See THIRD-PARTY.txt and LICENSE.txt. Contours, logs and embers: DeskDeck. */
const Campfire=(()=>{
 const W=40,H=44,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 function rnd(s){s.seed=(Math.imul(s.seed,1664525)+1013904223)>>>0;return s.seed/4294967296;}
 function create(){return {v:1,seed:7319,heat:Array(W*H).fill(0),time:0,last:0,carry:0};}
 function step(s,power){
  // Upstream's below-cell heat minus random decay; bounded neighbours never wrap.
  const old=s.heat,next=Array(W*H).fill(0);
  for(let y=0;y<H-1;y++)for(let x=1;x<W-1;x++){
   const decay=Math.floor(rnd(s)*3),sx=clamp(x+Math.floor(rnd(s)*3)-1,0,W-1);
   next[y*W+x]=Math.max(0,old[(y+1)*W+sx]-decay);
  }
  for(let x=1;x<W-1;x++){
   const edge=Math.sin(Math.PI*x/(W-1));
   next[(H-1)*W+x]=Math.round((25+power*10)*edge*(.85+rnd(s)*.15));
  }
  s.heat=next;s.time+=1/12;
 }
 function update(s,now,power){
  const dt=s.last?clamp((now-s.last)/1000,0,.25):0;s.last=now;s.carry+=dt;
  for(let n=0;s.carry>=1/12-1e-8&&n<3;n++){step(s,power);s.carry-=1/12;}
 }
 return {W,H,create,step,update};
})();
const widget={render(api){
 const c=api.canvas,power=({low:.55,medium:.8,high:1})[api.settings.intensity]||.8;
 let s=api.state;if(s.v!==1||!Array.isArray(s.heat)||s.heat.length!==Campfire.W*Campfire.H){s=Campfire.create();for(let i=0;i<60;i++)Campfire.step(s,power);}
 Campfire.update(s,api.now,power);api.state=s;
 const rect=(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(x,y,w,h);};
 const polygon=(pts,color)=>{c.fillStyle=color;c.beginPath();c.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)c.lineTo(pts[i][0],pts[i][1]);c.closePath();c.fill();};
 const ellipse=(x,y,rx,ry,color)=>{c.fillStyle=color;c.save();c.translate(x,y);c.scale(rx,ry);c.beginPath();c.arc(0,0,1,0,Math.PI*2);c.fill();c.restore();};
 rect(0,0,480,320,'#080C13');rect(0,264,480,56,'#0D1015');
 // Static ambient glow avoids changing every pixel just to flicker a background.
 for(let i=0;i<4;i++)ellipse(240,231,137-i*23,72-i*12,['#100E14','#1A1015','#271215','#3C1817'][i]);
 ellipse(240,281,127,13,'#05080C');
 for(const [x,y,w,angle] of [[184,260,116,.22],[274,265,112,-.26],[229,277,119,.02]]){
  c.save();c.translate(x,y);c.rotate(angle);rect(-w/2,-8,w,16,'#241A1B');rect(-w/2,-7,w,3,'#573228');rect(-w/2,4,w,3,'#120F13');
  for(let j=0;j<3;j++)rect(-w/2+14+j*25,-2,16,1,'#80503A');ellipse(w/2,0,6,8,'#6B4430');ellipse(w/2,0,3,5,'#291B1B');c.restore();
 }
 // Render nested heat contours instead of thousands of per-pixel draw commands.
 const colors=['#62201B','#A82D1A','#DE4A1C','#F77A25','#FFA940','#FFE2A0'];
 const thresholds=[3,8,14,20,26,31],left=132,bottom=268,dx=216/(Campfire.W-1),dy=4.3;
 for(let band=0;band<thresholds.length;band++){
  const pts=[[left,bottom]];
  for(let x=0;x<Campfire.W;x++){
   let y=Campfire.H-1;for(let row=0;row<Campfire.H;row++)if(s.heat[row*Campfire.W+x]>=thresholds[band]){y=row;break;}
   pts.push([left+x*dx,bottom-(Campfire.H-1-y)*dy]);
  }
  pts.push([left+216,bottom]);polygon(pts,colors[band]);
 }
 // Front charcoal restores depth around the base of the flame.
 polygon([[166,268],[215,260],[254,269],[302,265],[315,279],[225,286],[164,280]],'#1E1518');
 rect(204,273,14,2,'#E56A28');rect(256,277,18,2,'#B84120');
 if(api.settings.embers!==false)for(let i=0;i<9;i++){
  const age=(s.time*(.20+i*.011)+i*.137)%1,x=201+i*8+Math.sin(s.time*1.3+i*2)*age*19,y=253-age*153;
  c.globalAlpha=(1-age)*.8;rect(x,y,2,i%2?3:2,i%3?'#E98A3B':'#F6C879');
 }
 c.globalAlpha=1;
 if(api.settings.clock){const d=new Date(api.now);c.fillStyle='#A9A3A0';c.font='18px monospace';c.fillText(String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'),20,305);}
 const brightness=({dim:.35,normal:.12,bright:0})[api.settings.brightness]??.12;
 if(brightness){c.globalAlpha=brightness;rect(0,0,480,320,'#000000');c.globalAlpha=1;}
}};
