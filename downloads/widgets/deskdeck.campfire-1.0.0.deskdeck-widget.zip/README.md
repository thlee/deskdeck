# DeskDeck Campfire 1.0.0

Requires Studio with external JavaScript widgets; Aquarium requires package API 3 (Windows 0.8.26+ / current Mac Studio). Recommended: Studio 0.9.11 or newer. No firmware or Android app change is required.

## ko

모닥불·어항은 별도 ZIP 위젯입니다. Windows·Mac Studio의 전체화면 → 위젯 관리 목록에 ZIP을 압축을 풀지 않고 끌어다 놓으세요. 목록에서 위젯을 켜고 순서·사용 여부를 저장한 뒤 선택합니다. ‘위젯 설정’에서 옵션을 조정하고 저장합니다.

모닥불은 불꽃 세기·장면 밝기·불씨·작은 시계를 선택합니다. 화면 가운데를 터치하면 버튼 화면으로 돌아갑니다. 어항은 물고기 3·5·7마리, 헤엄 속도, 낮·밤 조명, 물방울, 처음 안내를 설정합니다. 물속을 터치하면 최대 8개의 먹이 알갱이를 두고 물고기가 따라옵니다. 먹이는 먹히거나 잠시 후 사라집니다. 어항에서는 오른쪽 위 ‘뒤로’로 복귀하며 자동 위젯 전환은 잠시 멈춥니다. 두 위젯 모두 가장자리 터치·스와이프로 다른 위젯으로 이동합니다.

소리와 인터넷 접속 없이 동작합니다. 애니메이션은 Studio에서 그려 기기로 전송하므로 Studio와의 연결이 필요합니다. 내부 그림은 자체 배경을 유지하고 바깥 여백은 기존 테마 설정을 따릅니다. 장면 밝기는 화면 그림을 어둡게 하는 옵션이며 기기의 실제 밝기 설정과는 다릅니다. 장면 진행·먹이는 일시 상태이며 Studio 재시작·패키지 교체·캐시 정리 시 초기화될 수 있습니다. 설정은 유지됩니다. 삭제·내보내기는 위젯 관리 목록의 우클릭 메뉴를 사용합니다.

## en

Campfire and Aquarium are separate ZIP widgets. In Windows or Mac Studio, drag the unopened ZIP onto Fullscreen → Widget management. Enable it, save order and enabled state, then select it. Change options in Widget settings and save.

Campfire offers flame intensity, scene brightness, floating embers and a small clock. Tap the middle of the screen to return to the button page. Aquarium offers 3/5/7 fish, swimming speed, day/night lighting, bubbles and a starting hint. Tap inside the water to add food (up to eight pellets); fish follow it and pellets are eaten or expire. Use Back at the top right to leave Aquarium; automatic widget rotation pauses in this interactive widget. Both widgets keep edge taps and swipes for switching widgets.

Both run offline and without sound. Studio draws and streams the animation, so the device must stay connected to Studio. The scene retains its own background; outer margins follow the existing theme settings. Scene brightness darkens the drawing, not the physical display brightness. Scene progress and food are temporary and may reset when Studio restarts, the package changes or its cache is cleared. Saved settings persist. Right-click the widget in Widget management to export or delete it.

## ja

焚き火（Campfire）と水槽（Aquarium） は別配布のZIPウィジェットです。Windows・MacのStudioで「全画面 → ウィジェット管理」の一覧にZIPを展開せずドラッグします。有効にし、順序・使用設定を保存して選択します。「ウィジェット設定」でオプションを変更して保存できます。

焚き火は炎の強さ・シーンの明るさ・火の粉・小さな時計を設定できます。画面中央をタップするとボタン画面に戻ります。水槽は魚3/5/7匹、泳ぐ速さ、昼/夜の照明、泡、開始時のヒントを設定できます。水中をタップすると最大8粒の餌を追加し、魚が追いかけます。餌は食べられるか時間経過で消えます。水槽は右上の「戻る」で終了します。操作型のため自動ウィジェット切り替えは停止します。どちらも画面端のタップやスワイプで他のウィジェットへ移動できます。

音声・インターネット接続は不要です。Studioが描画して送信するためStudioとの接続は必要です。シーン内は専用背景を保ち、外側の余白は既存テーマ設定に従います。シーンの明るさは描画の明るさであり、画面自体の輝度とは異なります。場面や餌は一時状態で、Studioの再起動・パッケージ更新・キャッシュ消去で初期化される場合があります。設定は保存されます。削除・書き出しは管理一覧の右クリックから行えます。

## zh-Hans

篝火（Campfire）和鱼缸（Aquarium）是单独提供的ZIP小组件。在Windows或Mac Studio的“全屏 → 小组件管理”列表中拖入ZIP，无需解压。启用并保存顺序与使用状态后选择它。在“小组件设置”中调整选项并保存。

篝火可设置火焰强度、场景亮度、飘浮火星和小型时钟。点击屏幕中央可返回按钮页面。鱼缸可设置3/5/7条鱼、游动速度、白天/夜间照明、气泡和初始提示。点击水中可投放食物（最多8粒），鱼会追逐食物。食物被吃掉或到期后消失。鱼缸使用右上角“返回”退出；交互式小组件会暂停自动轮换。两者都保留屏幕边缘点击和滑动切换小组件的操作。

无需联网，没有声音。动画由Studio绘制并传送，因此设备必须与Studio保持连接。场景内使用自身背景，外侧留白沿用现有主题设置。场景亮度只改变画面，不会改变设备的实际屏幕亮度。场景进度与食物属于临时状态，Studio重启、软件包更换或缓存清理后可能重置；设置会保留。可在管理列表中右键导出或删除。

## License / 라이선스

MIT for this widget package only. See LICENSE.txt and THIRD-PARTY.txt for full upstream notices, exact source revisions and modifications. This does not change the separate Studio license. The ZIP includes editable source; no extra asset download is required.
