# Photo slideshow
Requires Windows Studio 0.9.40+ or the corresponding macOS source build with the shared read-only local-images-v1 service.
Install the ZIP, open widget settings, add folders in playback order, and choose 3–300 seconds per image (default 10). Files are read in name order, followed by subfolders. Directory links and junctions are skipped and traversal is bounded to avoid cycles. Supported: JPEG, PNG, BMP, GIF (first frame), TIFF. Up to 20 folders and 5,000 files; oversized (>50 MB), corrupt, unreadable and symbolic-link images are skipped.
With no folders, installed theme-library backgrounds are used, with duplicate images removed. Missing/empty selected folders do not silently switch to themes. No image upload, network access, or executable widget script. Local folder paths remain in local options and are not included in ZIP exports. Images are downsampled with aspect ratio preserved. Folder/theme changes are refreshed within a minute.

Folder settings show multiple rows. Drag rows to reorder; right-click a row to remove the folder from the list (files are never deleted). Edits apply on Save; Cancel discards them. Random playback is off by default. When enabled, all selected photos (or theme backgrounds) are shuffled into one repeatable order for the current app session, so no photo repeats before the list wraps. Periodic rescans preserve the shuffled order of unchanged files. A new app session creates a new order. Existing options without `random` remain sequential.

## 1.1.1 폴더 선택
사진 폴더 추가로 한 목록에 폴더를 등록합니다. 각 행의 체크박스와 전체 선택/전체 해제로 표시 여부를 정합니다. 드래그 순서 변경과 우클릭 목록 삭제를 지원하며 사진 파일은 삭제하지 않습니다. 폴더가 없으면 테마 이미지를 사용하고, 등록한 폴더를 모두 해제하면 0장입니다. 선택 상태는 폴더 경로에 연결되어 순서를 바꿔도 유지됩니다. 저장 전에는 적용되지 않습니다. Mac build135 이상 및 대응 Windows Studio가 필요합니다.

이미지 팩은 원하는 곳에 압축을 풀고 사진이 들어 있는 images 폴더를 추가하세요. 별도 관리 목록이나 고정 설치 위치는 없습니다.

## 1.2.0 shared image service
Uses the shared read-only local-images-v1 host capability. Existing folder choices, order, timing and random-play options are preserved. Drop folders into Widget settings to add them. No permission to modify or delete source images.
