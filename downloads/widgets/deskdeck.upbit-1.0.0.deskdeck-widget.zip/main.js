const widget={render(api){
 const options=api.settings, codes=options.markets||['KRW-BTC','KRW-ETH'];
 const catalog=api.httpJson('https://api.upbit.com/v1/market/all?is_details=false',21600);
 const known=Array.isArray(catalog.data)?catalog.data:[];
 const valid=codes.filter(code=>!known.length||known.some(m=>m.market===code));
 const quote=valid.length?api.httpJson('https://api.upbit.com/v1/ticker?markets='+valid.slice().sort().join(','),options.interval||10):{data:null,updatedAt:0,failed:true};
 const prices=Array.isArray(quote.data)?quote.data:[];
 const previous=api.state.quotes||{};
 const complete=valid.length>0&&valid.every(code=>prices.some(q=>q.market===code&&Number.isFinite(q.trade_price)&&q.trade_price>0&&Number.isFinite(q.signed_change_rate)));
 if(complete)for(const q of prices)previous[q.market]={price:q.trade_price,change:q.signed_change_rate,updatedAt:quote.updatedAt};
 api.state.quotes=Object.fromEntries(codes.filter(c=>previous[c]).map(c=>[c,previous[c]]));
 const rows=codes.map(code=>{const m=known.find(m=>m.market===code),q=previous[code]||{};return {market:code,name:m?.korean_name||code.slice(4),english:m?.english_name||code.slice(4),...q};});
 const times=rows.map(r=>r.updatedAt||0);
 drawUpbit(api.canvas,{language:api.language,now:api.now,upbit:{rows,interval:options.interval||10,failed:quote.failed||!complete||rows.some(r=>!r.price),updatedAt:Math.min(...times)}},api.t);
}};
function drawUpbit(c,data,tr){
 const feed=data.upbit||{},rows=(feed.rows||[]).slice(0,10),now=data.now||Date.now();
 const stale=feed.failed||!feed.updatedAt||now-feed.updatedAt>Math.max(30,(feed.interval||10)*3)*1000;
 const font=(size,bold=false)=>{c.font=(bold?'600 ':'')+size+'px '+('sans-serif'||'sans-serif');};
 const fit=(text,width)=>{let value=String(text);while(value.length>1&&c.measureText(value).width>width)value=value.slice(0,-1);return value===String(text)?value:value.slice(0,-1)+'…';};
 c.textAlign='left';c.textBaseline='alphabetic';c.fillStyle='#E7EDF5';font(21,true);c.fillText(tr('upbit.title','코인 시세'),26,31);
 c.fillStyle='#9DAEC1';font(12);c.fillText('UPBIT · '+tr('upbit.market','원화마켓'),26,51);
 c.fillStyle=stale?'#EDBD77':'#9DAEC1';c.textAlign='right';font(11);
 const updated=feed.updatedAt?new Date(feed.updatedAt).toLocaleTimeString(undefined,{hour12:false}):'—';
 c.fillText((stale?tr('upbit.delayed','갱신 지연'):tr('upbit.updated','갱신'))+' '+updated,452,51);
 if(!rows.length){c.textAlign='center';font(16);c.fillText(tr('upbit.loading','시세 확인 중…'),240,170);return;}
 const cols=rows.length===1?1:2,count=Math.ceil(rows.length/cols),gap=8,w=(424-(cols-1)*gap)/cols,h=(222-(count-1)*gap)/count;
 for(let i=0;i<rows.length;i++){
  const r=rows[i],x=28+(i%cols)*(w+gap),y=65+Math.floor(i/cols)*(h+gap),compact=rows.length>6;
  c.fillStyle='#142231';c.beginPath();c.roundRect(x,y,w,h,8);c.fill();
  c.save();c.beginPath();c.rect(x+6,y+3,w-12,h-6);c.clip();
  c.textAlign='left';c.fillStyle='#C7D6E6';font(compact?11:14,true);
  const name=data.language==='ko'?(r.name||r.market):(r.english||r.name||r.market);
  c.fillText(fit(name+' '+String(r.market||'').replace('KRW-',''),w-16),x+8,y+(compact?13:rows.length<=2?23:18));
  const price=typeof r.price==='number'&&Number.isFinite(r.price)&&r.price>0?r.price:null;
  const formatted=price===null?'—':'₩'+price.toLocaleString('en-US',{maximumFractionDigits:price>=100?0:price>=1?2:price>=.01?4:8});
  font(compact?14:rows.length<=2?26:20,true);while(c.measureText(formatted).width>(compact?w-84:w-16)){const size=parseFloat(c.font.replace('600 ',''));if(size<=10)break;font(size-1,true);}
  c.fillStyle='#F0F5FA';c.fillText(formatted,x+8,y+(compact?30:rows.length<=2?h*.56:Math.max(40,h*.55)));
  const rate=typeof r.change==='number'&&Number.isFinite(r.change)?r.change:null;
  c.fillStyle=rate===null?'#9DAEC1':rate>0?'#F28787':rate<0?'#7DB5FF':'#9DAEC1';font(compact?10:14,true);
  // On dense cards reserve a separate right-aligned rate badge over the price row.
  if(compact){c.fillStyle='#142231';c.fillRect(x+w-70,y+17,64,18);c.fillStyle=rate===null?'#9DAEC1':rate>0?'#F28787':rate<0?'#7DB5FF':'#9DAEC1';c.textAlign='right';}
  c.fillText(rate===null?'—':(rate>0?'▲ +':rate<0?'▼ −':'')+Math.abs(rate*100).toFixed(2)+'%',compact?x+w-8:x+8,y+(compact?30:rows.length<=2?h*.82:h-9));
  c.restore();
 }
 c.textAlign='left';font(10);c.fillStyle='#9DAEC1';c.fillText(tr('upbit.change','전일 종가 대비 · 업비트 제공'),28,309);
}
