DeskDeck News 1.0.1

[한국어]
이 ZIP은 선택 설치하는 외장 뉴스 위젯입니다. 압축을 풀지 않고
Studio > 전체화면 위젯 > 위젯 관리 목록에 끌어다 놓으세요.
Studio 0.8.19 이상이 필요합니다.

1.0.1은 설치 및 업데이트 안내를 정리한 버전입니다.
기본 피드, 레이아웃, 권한은 1.0.0과 같습니다.
기존 위젯을 삭제하지 않고 같은 ID의 새 ZIP으로 업데이트하면 설정을 유지합니다.
위젯을 삭제하면 구독 설정도 삭제됩니다.

피드 체크박스/순서 변경, 여러 뉴스 표시, 수동 전환 및 스크롤 개선은
Studio가 제공하는 기능입니다. ZIP 교체만으로 Studio가 업데이트되지는 않습니다.
최근 개선은 2026-10-13 개발 소스에 반영되어 있으며, 기존 공개 Windows
0.8.19 설치파일에 모두 포함된 것은 아닙니다.
ESP32 자체 캐시·스크롤은 해당 기능을 지원하는 Studio와 펌웨어가 함께 필요합니다.
기본 뉴스 위젯 설치만을 위해 Android나 ESP32를 업데이트할 필요는 없습니다.

[English]
Optional external widget: drop this ZIP onto Studio > Fullscreen widgets > Manage widgets.
Requires Studio 0.8.19 or later. Keep the ZIP compressed.

Version 1.0.1 updates installation and upgrade guidance only.
Default feeds, layout and permissions are unchanged from 1.0.0.
Update the existing widget with the same ID to retain options; do not delete it first.
Deleting a widget removes its saved feed settings.

Feed selection/reordering, multiple headlines, navigation and scrolling are supplied by
Studio. Replacing this ZIP does not update Studio. Recent improvements are in the
2026-10-13 development source, not all in the published Windows 0.8.19 installer.
ESP32 local caching/scrolling needs a supporting Studio build and matching firmware.
Installing the basic widget alone does not require an Android or ESP32 update.

Default feed: NASA news releases (English)
https://www.nasa.gov/news-release/feed/
https://www.nasa.gov/rss-feeds/
https://www.nasa.gov/nasa-brand-center/images-and-media/

The package supplies layout and defaults; Studio supplies RSS/Atom retrieval,
settings and tap-to-open actions. This is a declarative package, with no scripts.
Only headlines, source, publication time and original links are displayed.
No article text or photographs are displayed. NASA does not endorse DeskDeck.
Check each provider's terms before adding other feeds.
Contact: deskdeck.app@gmail.com
