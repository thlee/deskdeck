/* Schooling separation/alignment/cohesion adapted from vscode-aquarium (MIT).
 * See THIRD-PARTY.txt and LICENSE.txt. All artwork and bounded feeding: DeskDeck. */
const Aquarium=(()=>{
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 function rnd(s){s.seed=(Math.imul(s.seed,1664525)+1013904223)>>>0;return s.seed/4294967296;}
 function create(count){const s={v:1,seed:51371,time:0,last:0,seq:0,eaten:0,food:[],fish:[]};for(let i=0;i<count;i++)s.fish.push({x:60+rnd(s)*360,y:80+rnd(s)*165,vx:(i%2?1:-1)*22,vy:0,dir:i%2?1:-1,phase:rnd(s)*6.28,kind:i%3});return s;}
 // Adapted from upstream's SCHOOLING_SPECIES branch; scaled to this small tank.
 function school(f,fish,speed){
  let sepX=0,sepY=0,sepN=0,sumVx=0,sumVy=0,sumX=0,sumY=0,nbN=0;
  const SEP_R=30,PERC_R=130;
  for(const o of fish){if(o===f||o.kind!==f.kind)continue;const dx=f.x-o.x,dy=f.y-o.y,d=Math.hypot(dx,dy)||1;
   if(d<SEP_R){sepX+=(dx/d)*(1-d/SEP_R);sepY+=(dy/d)*(1-d/SEP_R);sepN++;}
   if(d<PERC_R){sumVx+=o.vx;sumVy+=o.vy;sumX+=o.x;sumY+=o.y;nbN++;}
  }
  if(!nbN)return null;
  const cx=sumX/nbN-f.x,cy=clamp(sumY/nbN,70,260)-f.y,cd=Math.hypot(cx,cy)||1,ax=sumVx/nbN,ay=sumVy/nbN,av=Math.hypot(ax,ay)||1;
  let vx=cx/cd*speed*.5+ax/av*speed*.8,vy=cy/cd*speed*.5+ay/av*speed*.8;
  if(sepN){vx+=sepX*speed*2.2;vy+=sepY*speed*2.2;}return {vx,vy};
 }
 function step(s,dt,speed){
  s.time+=dt;
  for(const p of s.food){p.y+=9*dt;p.life-=dt;}s.food=s.food.filter(p=>p.life>0&&p.y<277);
  const velocities=s.fish.map(f=>{
   let target=null,distance=Infinity;for(const p of s.food){if(p.life<=0)continue;const d=Math.hypot(p.x-f.x,p.y-f.y);if(d<distance){target=p;distance=d;}}
   let vx=Math.sign(f.vx||1)*speed,vy=Math.sin(s.time*.45+f.phase)*7;
   if(target){const d=Math.max(1,distance);vx=(target.x-f.x)/d*speed*1.5;vy=(target.y-f.y)/d*speed*1.5;if(distance<13){target.life=0;s.eaten++;}}
   else{const b=school(f,s.fish,speed);if(b){vx=vx*.4+b.vx*.6;vy=vy*.4+b.vy*.6;}}
   if(f.x<60)vx+=speed*(60-f.x)/18;if(f.x>420)vx-=speed*(f.x-420)/18;
   if(f.y<75)vy+=(75-f.y)*2;if(f.y>250)vy-=(f.y-250)*2;
   const length=Math.hypot(vx,vy),max=speed*1.7;if(length>max){vx*=max/length;vy*=max/length;}return {vx,vy};
  });
  s.fish.forEach((f,i)=>{const a=1-Math.exp(-dt*2.4);f.vx+=(velocities[i].vx-f.vx)*a;f.vy+=(velocities[i].vy-f.vy)*a;f.x=clamp(f.x+f.vx*dt,32,448);f.y=clamp(f.y+f.vy*dt,60,270);f.dir+=(Math.sign(f.vx||f.dir)-f.dir)*Math.min(1,dt*4);});
  s.food=s.food.filter(p=>p.life>0);
 }
 function update(s,api,count,speed){
  if(s.fish.length!==count){const fresh=create(count);s.fish=fresh.fish;s.food=[];}
  if(api.active)for(const e of api.inputs||[]){if(e.sequence<=s.seq)continue;s.seq=e.sequence;
   if(e.x<22||e.x>457||e.y<48||e.y>277)continue;
   for(let i=0;i<3&&s.food.length<8;i++)s.food.push({x:clamp(e.x+(i-1)*8,34,446),y:clamp(e.y,62,250),life:16});
  }
  let dt=s.last?clamp((api.now-s.last)/1000,0,.25):0;s.last=api.now;
  // Passive previews show the tank but never consume food or touch input.
  if(api.active)while(dt>1e-6){const stepTime=Math.min(dt,1/24);step(s,stepTime,speed);dt-=stepTime;}
 }
 return {create,step,update,school};
})();
const widget={render(api){
 const c=api.canvas,count=({few:3,normal:5,many:7})[api.settings.fish_count]||5,speed=({slow:14,normal:23,fast:32})[api.settings.speed]||23;
 let s=api.state;if(s.v!==1||!Array.isArray(s.fish))s=Aquarium.create(count);Aquarium.update(s,api,count,speed);api.state=s;
 const night=api.settings.lighting==='night',rect=(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(x,y,w,h);};
 const poly=(pts,color)=>{c.fillStyle=color;c.beginPath();c.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)c.lineTo(pts[i][0],pts[i][1]);c.closePath();c.fill();};
 const circle=(x,y,r,color)=>{c.fillStyle=color;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();};
 const water=night?['#081422','#091A29','#0A202E','#0B2733','#0C2B36','#10313A']:['#123C53','#13445B','#154B60','#165365','#185A69','#1B616B'];
 for(let i=0;i<6;i++)rect(0,i*48,480,49,water[i]);
 c.globalAlpha=night?.025:.07;poly([[80,0],[115,0],[270,280],[202,280]],'#D3F1DD');poly([[291,0],[310,0],[376,280],[323,280]],'#D3F1DD');c.globalAlpha=1;
 // Sand, pebbles and slow kelp silhouettes are entirely procedural artwork.
 poly([[0,277],[90,273],[190,282],[301,275],[390,280],[480,272],[480,320],[0,320]],night?'#263439':'#817E64');
 for(let i=0;i<12;i++)rect((i*83+13)%480,286+(i*17)%29,4+i%4,2,night?'#405052':'#ADA384');
 for(const [x,h,color] of [[32,115,'#235951'],[55,82,'#397365'],[420,106,'#285C53'],[447,136,'#3D7662']]){
  const points=[];for(let i=0;i<=6;i++)points.push([x+Math.sin(s.time*.55+i*.7+x)*i*1.4-3,280-h*i/6]);
  for(let i=6;i>=0;i--)points.push([x+Math.sin(s.time*.55+i*.7+x)*i*1.4+3,280-h*i/6]);poly(points,night?'#183E3B':color);
 }
 poly([[68,280],[77,260],[102,255],[121,274],[120,283]],night?'#283E42':'#49666A');poly([[338,281],[344,263],[366,259],[382,280]],night?'#2D4143':'#58706B');
 if(api.settings.bubbles!==false)for(let i=0;i<5;i++){
  const age=(s.time*(.08+i*.003)+i*.19)%1;c.globalAlpha=.22+age*.2;c.strokeStyle=night?'#63818B':'#A5D6DA';c.lineWidth=1;c.beginPath();c.arc(404+Math.sin(age*9+i)*5,280-age*230,2+i%3,0,Math.PI*2);c.stroke();
 }c.globalAlpha=1;
 const bodies=['#EBAB55','#6BC5C6','#DA8094'],fins=['#B66838','#3A8E9D','#A74B70'];
 for(const f of s.fish){
  c.save();c.translate(f.x,f.y);c.rotate(Math.max(-.35,Math.min(.35,f.vy/90))*Math.sign(f.dir||1));c.scale(Math.abs(f.dir)<.14?.14:f.dir,1);
  const wiggle=Math.sin(s.time*7+f.phase)*3;
  poly([[-14,0],[-26,-9+wiggle],[-24,8+wiggle]],fins[f.kind]);
  poly([[-6,-6],[0,-15],[10,-8]],fins[f.kind]);
  poly([[-17,0],[-11,-7],[-2,-10],[9,-8],[17,-3],[20,0],[16,5],[7,9],[-3,8],[-12,5]],bodies[f.kind]);
  poly([[-6,1],[3,2],[-1,9]],fins[f.kind]);
  c.strokeStyle=fins[f.kind];c.lineWidth=1;c.beginPath();c.moveTo(9,-5);c.lineTo(8,4);c.stroke();
  circle(13,-2,2,'#F5F1DD');circle(14,-2,1,'#142B35');c.restore();
 }
 for(const p of s.food)rect(p.x-1,p.y-1,3,3,'#EAC58B');
 if(api.settings.hint!==false&&s.time<7){c.fillStyle=night?'#A5B9BD':'#D1DFD8';c.font='12px sans-serif';c.textAlign='center';c.fillText(api.t('feed_hint','Tap the water to feed fish'),240,307);}
 if(night){c.globalAlpha=.16;rect(0,0,480,320,'#000818');c.globalAlpha=1;}
}};
