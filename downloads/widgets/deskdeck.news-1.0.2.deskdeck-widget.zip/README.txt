DeskDeck News 1.0.2

[한국어]
이 ZIP은 선택 설치하는 외장 뉴스 위젯입니다. 압축을 풀지 않고
Studio > 전체화면 위젯 > 위젯 관리 목록에 끌어다 놓으세요.
2026-10-17 뉴스 테마 배경 지원 수정판 Studio가 필요합니다.

1.0.2는 현재 테마를 뉴스 카드 사이와 화면 가장자리 배경에 표시합니다.
뉴스 제목 카드·스크롤·조작과 기본 피드·권한은 유지합니다.
테마와 카드 배경은 현재 Studio의 표시 설정을 따릅니다.
기존 위젯을 삭제하지 않고 같은 ID의 새 ZIP으로 업데이트하면 설정을 유지합니다.
위젯을 삭제하면 구독 설정도 삭제됩니다.

피드 체크박스/순서 변경, 여러 뉴스 표시, 수동 전환 및 스크롤 개선은
Studio가 제공하는 기능입니다. ZIP 교체만으로 Studio가 업데이트되지는 않습니다.
현재 공개 Windows Studio 0.9.31 사용을 권장합니다.
ESP32 자체 캐시·스크롤은 해당 기능을 지원하는 Studio와 펌웨어가 함께 필요합니다.
기본 뉴스 위젯 설치만을 위해 Android나 ESP32를 업데이트할 필요는 없습니다.

[English]
Optional external widget: drop this ZIP onto Studio > Fullscreen widgets > Manage widgets.
Requires the 2026-10-17 Studio news theme-background update. Keep the ZIP compressed.

Version 1.0.2 applies the current theme behind news cards and in screen margins.
Cards, scrolling, controls, feeds and permissions are unchanged. Theme rendering
follows the current Studio display settings.
Update the existing widget with the same ID to retain options; do not delete it first.
Deleting a widget removes its saved feed settings.

Feed selection/reordering, multiple headlines, navigation and scrolling are supplied by
Studio. Replacing this ZIP does not update Studio. The current public Windows
Studio 0.9.31 release is recommended.
ESP32 local caching/scrolling needs a supporting Studio build and matching firmware.
Installing the basic widget alone does not require an Android or ESP32 update.

Default feed: NASA news releases (English)
https://www.nasa.gov/news-release/feed/
https://www.nasa.gov/rss-feeds/
https://www.nasa.gov/nasa-brand-center/images-and-media/

The package supplies layout and defaults; Studio supplies RSS/Atom retrieval,
settings and tap-to-open actions. This is a declarative package, with no scripts.
Only headlines, source, publication time and original links are displayed.
No article text or photographs are displayed. NASA does not endorse DeskDeck.
Check each provider's terms before adding other feeds.
Contact: deskdeck.app@gmail.com
