/* Original DeskDeck reversi implementation. No network, assets or operating-system actions. */
const Othello = (()=>{
 const dirs=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
 function initial(){const b=Array(64).fill(0);b[27]=b[36]=-1;b[28]=b[35]=1;return b;}
 function flips(b,i,p){if(i<0||i>=64||b[i])return [];const all=[],r=i>>3,c=i%8;for(const [dr,dc] of dirs){let y=r+dr,x=c+dc,line=[];while(y>=0&&y<8&&x>=0&&x<8&&b[y*8+x]===-p){line.push(y*8+x);y+=dr;x+=dc;}if(line.length&&y>=0&&y<8&&x>=0&&x<8&&b[y*8+x]===p)all.push(...line);}return all;}
 function moves(b,p){const a=[];for(let i=0;i<64;i++)if(!b[i]&&flips(b,i,p).length)a.push(i);return a;}
 function place(b,i,p){const f=flips(b,i,p);if(!f.length)return null;const n=b.slice();n[i]=p;for(const k of f)n[k]=p;return n;}
 function counts(b){return {black:b.filter(v=>v===1).length,white:b.filter(v=>v===-1).length};}
 function next(b,p){if(moves(b,-p).length)return {turn:-p,over:false,pass:0};if(moves(b,p).length)return {turn:p,over:false,pass:-p};return {turn:0,over:true,pass:0};}
 function score(b,p){let s=0,empty=b.filter(x=>!x).length;for(let i=0;i<64;i++){const r=i>>3,c=i%8;s+=b[i]*p*((r===0||r===7)&&(c===0||c===7)?140:(r===0||r===7||c===0||c===7)?5:empty<12?3:1);}for(const [corner,near] of [[0,[1,8,9]],[7,[6,14,15]],[56,[48,49,57]],[63,[54,55,62]]])if(!b[corner])for(const i of near)s-=b[i]*p*24;return s+10*(moves(b,p).length-moves(b,-p).length);}
 function ai(b,p,level){const legal=moves(b,p);if(!legal.length)return -1;let nodes=0;const deadline=Date.now()+90,limit=level==='easy'?1:3;
  function search(board,turn,depth,alpha,beta){if(++nodes>6000||Date.now()>deadline||depth<=0)return score(board,p);const ms=moves(board,turn);if(!ms.length){if(!moves(board,-turn).length){const c=counts(board);return (c.black-c.white)*p*1000;}return search(board,-turn,depth-1,alpha,beta);}let best=turn===p?-Infinity:Infinity;for(const i of ms){const v=search(place(board,i,turn),-turn,depth-1,alpha,beta);if(turn===p){best=Math.max(best,v);alpha=Math.max(alpha,best);}else{best=Math.min(best,v);beta=Math.min(beta,best);}if(beta<=alpha)break;}return best;}
  let pick=legal[0],best=-Infinity;for(const i of legal){const v=search(place(b,i,p),-p,limit-1,-Infinity,Infinity);if(v>best){best=v;pick=i;}}return pick;
 }
 return {initial,flips,moves,place,counts,next,ai};
})();
const widget={render(api){
 const c=api.canvas,t=api.t,now=api.now,mode=api.settings.mode||'ai',level=api.settings.level||'normal',config=mode+':'+level;
 const fresh=()=>({board:Othello.initial(),turn:1,over:false,last:-1,config,undo:null,aiAt:0,notice:'',noticeUntil:0,confirmUntil:0});
 let s=api.state;if(!Array.isArray(s.board)||s.board.length!==64||s.config!==config)s=fresh();
 const move=(i)=>{const b=Othello.place(s.board,i,s.turn);if(!b)return false;s.board=b;s.last=i;const n=Othello.next(b,s.turn);s.turn=n.turn;s.over=n.over;s.notice=n.pass===1?'black_pass':n.pass===-1?'white_pass':'';s.noticeUntil=now+2500;s.aiAt=now+600;return true;};
 for(const e of api.inputs||[]){
  if(e.x>=304&&e.x<452&&e.y>=256&&e.y<300){if(s.over||s.confirmUntil>now)s=fresh();else s.confirmUntil=now+3500;continue;}
  if(e.x>=304&&e.x<452&&e.y>=208&&e.y<248&&s.undo){const old=s.undo;s.board=old.board.slice();s.turn=old.turn;s.last=old.last;s.over=false;s.undo=null;s.notice='';s.confirmUntil=0;s.aiAt=now+600;continue;}
  if(s.over||(mode==='ai'&&s.turn!==1))continue;
  if(e.x>=28&&e.x<284&&e.y>=56&&e.y<312){const i=Math.floor((e.y-56)/32)*8+Math.floor((e.x-28)/32);if(Othello.flips(s.board,i,s.turn).length){s.undo={board:s.board.slice(),turn:s.turn,last:s.last};s.confirmUntil=0;move(i);}}
 }
 if(api.active&&mode==='ai'&&s.turn===-1&&!s.over&&now>=s.aiAt){const i=Othello.ai(s.board,-1,level);if(i>=0)move(i);}
 api.state=s;const count=Othello.counts(s.board),legal=Othello.moves(s.board,s.turn),hint=api.settings.hints!==false&&!s.over&&(mode==='local'||s.turn===1);
 const rect=(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(x,y,w,h);};
 const text=(label,x,y,size,color='#DDEEE7',align='left')=>{c.font='600 '+size+'px sans-serif';c.fillStyle=color;c.textAlign=align;c.textBaseline='middle';c.fillText(String(label),x,y,align==='center'&&x===378?140:400);};
 const disc=(x,y,r,color)=>{c.fillStyle=color;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();};
 rect(0,0,480,320,'#0B1B18');text(t('title','Othello'),28,24,23);text(t(mode==='local'?'local':'you_black',mode==='local'?'2 players':'You play black'),286,24,12,'#9CB9AD','right');
 rect(28,56,256,256,'#225E4B');
 for(let r=0;r<8;r++)for(let col=0;col<8;col++){
  const i=r*8+col,x=28+col*32,y=56+r*32;if((r+col)%2)rect(x,y,32,32,'#1C5543');
  if(s.board[i]){disc(x+16,y+18,12,'#163D31');disc(x+16,y+15,12,s.board[i]===1?'#101B1A':'#EAF0DB');if(i===s.last)disc(x+16,y+15,3,s.board[i]===1?'#78E2BC':'#2B7056');}
  else if(hint&&legal.includes(i))disc(x+16,y+16,3,'#79B69A');
 }
 rect(304,56,148,70,'#152E27');disc(322,77,8,'#080F0D');disc(396,77,8,'#EAF0DB');text(count.black,322,105,26,'#ECF3E5','center');text(count.white,396,105,26,'#ECF3E5','center');text(t(mode==='ai'?'you':'black',mode==='ai'?'YOU':'BLACK'),341,78,10);text(t(mode==='ai'?'pc':'white',mode==='ai'?'PC':'WHITE'),410,78,10);
 let status=s.over?(count.black===count.white?'draw':count.black>count.white?'black_wins':'white_wins'):(mode==='ai'?(s.turn===1?'your_turn':'thinking'):(s.turn===1?'black_turn':'white_turn'));
 text(t(status,status),378,151,16,'#8DE2BE','center');
 text(t(s.notice&&now<s.noticeUntil?s.notice:s.over?'finished':hint?'tap_dot':'wait',s.over?'Game over':'Tap a dot'),378,179,11,'#A3BCAF','center');
 rect(304,208,148,40,s.undo?'#26483B':'#142C25');text(t('undo','Undo'),378,228,14,s.undo?'#DDEEE7':'#637F70','center');
 rect(304,256,148,44,s.confirmUntil>now?'#795235':'#315D47');text(t(s.confirmUntil>now?'confirm':'new_game',s.confirmUntil>now?'Tap to restart':'New game'),378,278,14,'#F0F2DF','center');
 text(t('memory','Saved until Studio closes'),378,311,9,'#7C9E8B','center');
}};
