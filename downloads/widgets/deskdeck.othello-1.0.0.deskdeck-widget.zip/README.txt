DeskDeck Othello 1.0.0
Requires Studio 0.8.26+ (interactive ZIP API 3). No firmware or Android app update required.
Drag this ZIP into Fullscreen > Manage widgets. Select Othello and Show on device.
Black moves first. Tap a marked square. Passes and game end are automatic.
Widget settings: computer / two players, difficulty, legal move hints. Changing mode/difficulty restarts the game.
Undo restores the previous human turn (including the computer response). New game requires a second tap during play.
Top-right arrow returns to buttons. Screen edges / swipe switch widgets. Automatic widget rotation is paused for interactive packages.
Game remains in Studio memory while switching widgets; restarting Studio resets it. No network or personal data is used.
Original DeskDeck code and vector drawing; no third-party game assets.
