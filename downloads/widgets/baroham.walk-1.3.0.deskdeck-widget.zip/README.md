# 바루와 하미 · Baru & Hami

One optional offline ZIP widget shared by Mac and Windows. It replaces the previous Baroham Walk package, keeping the `baroham.walk` ID and existing settings.

Choose Character (Hami / Baru) and Season:
- Spring: light shirt and school courtyard.
- Summer: swimwear and beach.
- Autumn: uniform/cardigan and autumn foliage garden.
- Winter: warm coat/scarf and snow-covered ski resort.

Size, speed, current-theme/season/plain background, and initial touch hint remain configurable. The companion walks, waves, rests and sleeps; tapping an open part of the screen wakes it and makes it follow. Navigation stays under Studio control.

Version 1.3.0 requires the updated Studio with ZIP-local image assets, smooth sprite rendering and additive settings migration. No firmware update or internet access is required. Import this ZIP in Widget management on each PC. It is not bundled automatically with Studio.

Original PNG artwork: artwork/baroham/. The compiler reads images and emits aligned source coordinates; packaged WebP/JPEG assets retain smooth alpha and full colour. No third-party downloaded character art is included.
