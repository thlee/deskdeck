# 휴식 · Relax · くつろぎ · 休闲

## ko

풍경은 Studio에 설정된 지역의 최신 날씨도 반영합니다. 맑음은 밝은 하늘, 흐림은 구름과 낮아진 밝기, 비와 눈은 움직이는 빗줄기와 눈송이로 표시합니다. 낮·밤·현재 시각 모두 최신 날씨를 사용하며 시간대 선택은 하늘의 시각을 정합니다. 강수·짙은 구름에서는 해와 달, 별빛과 수면 반사를 가립니다. 날씨 정보가 없거나 유효기간이 지나면 강수 효과를 끕니다. 위젯은 날씨 서버에 별도 요청을 보내지 않습니다. Studio 0.9.49 이상과 휴식 ZIP 1.1.2 이상이 필요합니다.

어항, 모닥불, 빗소리 창가, 풍경 중 한 장면을 보거나 30초·1분·5분마다 순환할 수 있습니다. 화면을 탭하면 버튼 화면으로 돌아가고, 좌우 가장자리나 스와이프로 다른 위젯을 엽니다. 복귀 안내는 장면 시작 후 약 7초간 표시되며 설정에서 끌 수 있습니다.

1.1.0부터 기존 ‘밤하늘’은 ‘풍경’으로 표시되며 기존 선택은 밤으로 이어집니다. 풍경에서 시간대와 바라보는 방향을 고르세요. ‘현재 시각’은 현재의 하늘을, ‘낮’과 ‘밤’은 날씨 위치에서 같은 태양일의 정오와 자정 하늘을 보여줍니다. Studio가 날씨에 사용하는 위치를 기준으로 해와 달의 방위·고도와 달의 밝은 부분을 계산합니다. 예를 들어 해질 무렵 서쪽을 보면 해가 보이지만, 동쪽으로 돌아서거나 해가 지형 뒤로 내려가면 보이지 않습니다. 산과 호수는 손으로 구성한 가상 풍경입니다. 위치를 확인하기 전에는 배경만 그리며, ‘현재 시각’의 조명은 PC 시각을 따릅니다. 위젯에는 천체 계산 결과만 전달됩니다.

빗소리는 기본으로 꺼져 있습니다. 소리를 켜면 Android 기기에 저장해 재생하며, 가상 화면만 열려 있으면 PC에서 재생합니다. 미리보기와 ESP32는 무음이고 화면 종료·소등 시 재생이 멈춥니다. 첫 설치 시 기존 어항·모닥불 설정을 가져옵니다. 원래 패키지는 보존되며 휴식을 삭제하면 다시 목록에 나타납니다. 1.1.0에는 Studio 0.9.46 이상이 필요하며, Android 오디오는 휴대폰 앱 0.5.56 이상에서 지원합니다.

## en

Landscape also follows the latest weather for the region configured in Studio. Clear weather gives an open sky, clouds dim the scene, and rain or snow adds moving drops or flakes. All three time modes use the latest weather, while the time choice controls the sky instant. Precipitation and dense cloud hide the Sun, Moon, stars and their water reflection. Missing or expired weather removes precipitation effects. The widget makes no separate weather-server requests. Requires Studio 0.9.49+ and Relax ZIP 1.1.2+.

Choose Aquarium, Campfire, Rainy window or Landscape, or cycle through all four every 30 seconds, 1 minute or 5 minutes. Tap a scene to return to the button page. Use the edges or swipe to switch widgets. The optional return hint appears for about seven seconds at the start of each scene.

In 1.1.0, Night sky becomes Landscape and keeps its Night setting. Choose the time of day and compass direction. Current time follows the actual sky. Day and Night use local solar noon and midnight on the same solar date at the weather location. Studio calculates the Sun and Moon’s direction and elevation, the lunar phase and the orientation of the illuminated limb. Face west at sunset to see the Sun when it is above the illustrated ridgeline. The lake and terrain are fictional. Until a weather location is available, only the scenery appears and Current time uses the PC clock for lighting. The widget receives only the calculated sky data.

Rain sound defaults to off. When enabled, the connected Android device caches and plays it. The PC plays audio in virtual-display-only sessions. Previews and the ESP32 are silent. Leaving the widget or turning off the screen stops playback. The first installation imports existing Aquarium and Campfire settings. Their packages are preserved and reappear in the list if you remove Relax. Version 1.1.0 needs Studio 0.9.46 or newer. Android audio requires phone app 0.5.56 or newer.

## ja

風景にも Studio で設定した地域の最新の天気を反映します。晴れは明るい空、曇りは雲と落ち着いた明るさ、雨や雪は動く雨粒や雪片で表します。昼・夜・現在時刻のどのモードでも最新の天気を使い、時間帯の選択で空の時刻を決めます。雨雪や厚い雲では太陽・月・星と水面の反射を隠します。天気が不明または期限切れなら雨雪の演出を止めます。ウィジェットから天気サーバーへの追加通信はありません。Studio 0.9.49 以降とくつろぎ ZIP 1.1.2 以降が必要です。

水槽・焚き火・雨の窓辺・風景からシーンを選ぶか、30秒・1分・5分ごとに4つを循環できます。画面をタップするとボタン画面に戻ります。左右端の操作やスワイプで別のウィジェットに移動できます。シーン開始時に約7秒間表示される操作ヒントは設定でオフにできます。

1.1.0では「夜空」が「風景」になり、以前の選択は「夜」として引き継がれます。時間帯と眺める方角を選べます。「現在時刻」は現在の空を、「昼」と「夜」は天気の地点における同じ太陽日の正午と真夜中の空を表示します。Studio が天気の地点から太陽と月の方位・高度、月の満ち欠けと明るい側の向きを計算します。例えば日没時に西を向くと、山の稜線に隠れるまで夕日が見えます。湖と地形は架空の風景です。地点が分かるまでは背景だけを描き、「現在時刻」の明るさはPCの時計に合わせます。ウィジェットは計算済みの天体情報だけを受け取ります。

雨音は初期設定でオフです。オンにすると接続した Android 端末に保存して再生します。仮想画面だけを使用するときは PC が再生します。プレビューと ESP32 は無音で、画面の終了・消灯時には再生を停止します。初回インストールで以前の水槽・焚き火の設定を引き継ぎます。元のパッケージは保管され、くつろぎを削除すると再び一覧に表示されます。1.1.0には Studio 0.9.46 以降が必要です。Android の音声再生には端末側アプリ 0.5.56 以降が必要です。

## zh-Hans

风景也会反映 Studio 所设地区的最新天气。晴天显示明亮天空，阴天增加云层并调暗场景，雨雪则显示移动的雨滴或雪花。白天、夜晚和当前时间均使用最新天气，时段选项控制天空对应的时刻。降水和厚云会遮住日月、星光及水面反射。天气缺失或过期时停止雨雪效果。小组件不会额外请求天气服务器。需要 Studio 0.9.49 及以上和休闲 ZIP 1.1.2 及以上。

可以选择水族箱、篝火、雨中窗边或风景，也可以每 30 秒、1 分钟或 5 分钟轮换四个场景。轻触画面即可返回按钮页面，使用左右边缘控件或滑动可切换小组件。每个场景开始时会显示约 7 秒的返回提示，可在设置中关闭。

从 1.1.0 起，“夜空”更名为“风景”，原先选中的夜空会保留为“夜晚”。可以选择时段和朝向。“当前时间”显示此刻的天空，“白天”和“夜晚”分别显示天气地点在同一太阳日的正午和午夜。Studio 根据天气地点计算太阳和月亮的方位、高度，以及月相和亮面朝向。例如，日落时朝西就能看到太阳，直到它隐入山后。湖泊和山脉均为虚构场景。尚未取得天气地点时只绘制背景，“当前时间”的光线随电脑时钟变化。小组件只接收计算后的天体数据。

雨声默认关闭。开启后，已连接的 Android 设备会缓存并播放音频；仅使用虚拟屏幕时由电脑播放。预览和 ESP32 均为静音，退出小组件或关闭屏幕时停止播放。首次安装会导入原有水族箱和篝火的设置。原包保留，删除休闲后会重新出现在列表中。1.1.0 需要 Studio 0.9.46 或更高版本。Android 音频需要手机端应用 0.5.56 或更高版本。

## License / 라이선스

MIT. See LICENSE.txt and THIRD-PARTY.txt. Aquarium schooling and campfire heat diffusion retain their original MIT notices. The illustrated landscape, rainy window and synthesized PCM rain sound are original work.

This passive package uses the host's sky, settings and audio capabilities. Build with `python scripts/build-relax-widget.py` followed by `python scripts/build-widget-packages.py --package relax`. The resulting ZIP installs separately from Studio.

## 2026-11-07 Windows 통합판

Studio **0.9.48** / 휴식 **1.1.1**은 Mac에서 추가한 풍경(동서남북·현재/낮/밤)과 이 PC의 자연 녹음 비·모닥불, 장면별 음량 및 한 줄 선택 설정을 함께 보존합니다. 14개 설정 중 기존 12개 값은 유지하고 풍경 시간/방향의 기본값을 추가합니다. 음량은 비·모닥불 장면에서만 보입니다. 새 풍경은 `sky:1`을 사용하며 기존 패키지용 `astronomy:1`도 유지합니다. 두 기능 모두 날씨 위치의 허용 상태를 확인한 뒤 계산하고 좌표 자체는 위젯에 전달하지 않습니다.

빗소리·모닥불 소리는 CC0 녹음이며 LICENSE-CC0.txt, AUDIO-SOURCES.json, THIRD-PARTY.txt에 출처와 처리 정보를 동봉합니다. 이는 아래 이전 버전의 자체 합성음 설명을 대체합니다. 장면 코드·그림은 기존 MIT 고지를 유지합니다. 공개 배포는 하지 않습니다. Windows 빌드·검사·설치 결과는 windows-validation-c7b85c7.md에 기록합니다. Mac은 통합 소스 반영이며 이번 Windows 작업에서 네이티브 실행을 검증하지 않습니다.
