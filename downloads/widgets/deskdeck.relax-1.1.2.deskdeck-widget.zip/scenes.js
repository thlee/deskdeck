/* Original procedural scenes, Baroham. MIT; no remote images or recordings. */
const RelaxScenes=(()=>{
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 function rect(c,x,y,w,h,color){c.fillStyle=color;c.fillRect(x,y,w,h);}
 function poly(c,points,color){c.fillStyle=color;c.beginPath();c.moveTo(...points[0]);for(let i=1;i<points.length;i++)c.lineTo(...points[i]);c.closePath();c.fill();}
 function circle(c,x,y,r,color){c.fillStyle=color;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();}
 function line(c,x,y,x2,y2,color,width=1){c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(x,y);c.lineTo(x2,y2);c.stroke();}
 function rain(api,s){
  const c=api.canvas,t=s.time;
  rect(c,0,0,480,320,'#241F29');rect(c,39,24,402,236,'#141F35');
  for(let i=0;i<8;i++)rect(c,47,32+i*27,386,28,['#172339','#1B2B40','#203147','#26394D','#2B4053','#31495B','#385362','#3F5B68'][i]);
  // Distant roofs and subdued window lights stay behind the wet glass.
  poly(c,[[48,211],[48,165],[94,165],[94,139],[126,139],[126,181],[165,181],[165,154],[206,154],[206,205],[250,205],[250,165],[286,165],[286,133],[321,133],[321,183],[355,183],[355,160],[400,160],[400,191],[433,191],[433,246],[48,246]],'#172B3D');
  c.globalAlpha=.55;for(let i=0;i<16;i++)rect(c,60+(i*73)%357,174+(i*29)%58,3,5,i%3?'#A49C77':'#607A83');c.globalAlpha=1;
  // A bounded number of long rivulets: quiet movement, no flashing lightning.
  for(let i=0;i<23;i++){
   const x=55+(i*67)%368,y=34+((t*(19+i%5*4)+i*47)%194);
   c.globalAlpha=.16+(i%3)*.05;line(c,x,y,x-3,y+12+i%4*3,'#BED5DB');
  }c.globalAlpha=1;
  for(let i=0;i<7;i++){const y=43+((t*9+i*33)%188);rect(c,69+(i*47)%350,y,2,3,'#A3BBC6');}
  // Deep timber frame, reflection, sill and a warm reading lamp.
  rect(c,31,18,418,12,'#44343A');rect(c,31,18,12,251,'#594047');rect(c,437,18,12,251,'#372C36');
  rect(c,232,29,10,227,'#493842');rect(c,44,140,393,7,'#493842');rect(c,242,29,2,227,'#71606A');
  rect(c,25,256,430,12,'#705350');rect(c,19,268,442,8,'#362931');
  rect(c,0,284,480,36,'#32262D');rect(c,0,284,480,3,'#795546');
  c.globalAlpha=.18;poly(c,[[58,191],[114,191],[165,284],[9,284]],'#E6AD6A');c.globalAlpha=1;
  rect(c,83,194,5,83,'#B88B67');poly(c,[[63,160],[108,160],[122,195],[49,195]],'#BF8459');rect(c,49,194,73,4,'#E4B47B');
  poly(c,[[63,277],[111,277],[120,283],[54,283]],'#755245');
  rect(c,310,282,66,5,'#9C8273');rect(c,318,274,60,7,'#6B7181');rect(c,321,275,54,2,'#C4AD91');
  // Cup handle touches the body; steam is drawn with short soft strokes.
  line(c,402,261,412,262,'#BCA99B',4);line(c,412,262,412,273,'#BCA99B',4);line(c,412,273,401,275,'#BCA99B',4);
  poly(c,[[379,255],[404,255],[401,282],[383,282]],'#CCBBA7');rect(c,380,255,23,3,'#624C49');
  for(let i=0;i<2;i++){const x=387+i*9+Math.sin(t*.8+i)*2;c.globalAlpha=.25;line(c,x,246,x+Math.sin(t+i)*3,234,'#CFBFB2');}c.globalAlpha=1;
 }
 // Four views from the same fictional lakeshore. The terrain is illustrative;
 // only the celestial bodies use the weather location's horizontal coordinates.
 const views = {
  east:  {bearing:90, far:[211,192,169,185,208,223,231,214,201,208,218,197,182], near:[236,221,218,225,240,247,248,245,240,236,224,215,222]},
  south: {bearing:180,far:[218,211,216,228,237,242,244,240,236,226,220,213,222], near:[235,230,242,248,252,253,254,254,251,247,240,234,235]},
  west:  {bearing:270,far:[200,205,214,216,227,233,239,235,232,222,212,203,205], near:[226,222,234,240,247,248,250,251,246,243,234,228,225]},
  north: {bearing:0,  far:[213,203,180,190,207,184,160,143,164,177,168,192,205], near:[232,226,221,235,242,230,213,202,210,221,214,220,227]}
 };
 const horizon = 253;
 const radians = Math.PI / 180;
 function bearingOffset(azimuth, bearing) { return ((azimuth - bearing + 540) % 360) - 180; }
 function skyPoint(body, bearing) {
  if (!body || !Number.isFinite(body.azimuth) || !Number.isFinite(body.altitude) || body.altitude < 0) return null;
  const offset = bearingOffset(body.azimuth, bearing);
  // Adjacent 96° views overlap slightly at their edges. Zenith stays on screen.
  if (Math.abs(offset) > 48) return null;
  return {x:240 + offset * 5, y:horizon - Math.min(90, body.altitude) * 2.65};
 }
 function mixColor(first, second, weight) {
  const channel = shift => Math.round(((first >> shift) & 255) * (1-weight) + ((second >> shift) & 255) * weight);
  return (channel(16) << 16) + (channel(8) << 8) + channel(0);
 }
 function hex(color) { return '#' + color.toString(16).padStart(6,'0'); }
 function fallbackLight(mode, now) {
  if (mode === 'day') return 40;
  if (mode === 'night') return -22;
  const date = new Date(now);
  return 27 * Math.cos((date.getHours() + date.getMinutes()/60 - 12) * Math.PI/12);
 }
 function ridge(c, heights, color) {
  const outline = heights.map((y,i) => [i*40,y]);
  poly(c,[...outline,[480,320],[0,320]],color);
 }
 function pine(c, x, base, size, color) {
  const silhouette = [[0,0],[-.12,.29],[-.055,.29],[-.19,.54],[-.09,.53],[-.25,.79],[-.11,.78],[-.30,.94],[-.04,.93],[-.04,1],[.04,1],[.04,.93],[.27,.94],[.11,.76],[.23,.78],[.10,.55],[.17,.58],[.05,.29],[.12,.31]];
  poly(c,silhouette.map(([dx,dy]) => [x+dx*size,base-(1-dy)*size]),color);
 }
 function cloud(c,x,y,width,height,color) {
  const points = [[0,.64],[.15,.51],[.25,.42],[.32,.14],[.46,.06],[.56,.32],[.70,.38],[.77,.51],[.92,.61],[1,.73],[.74,.84],[.38,.83],[.11,.77]];
  poly(c, points.map(([dx,dy]) => [x+dx*width,y+dy*height]), color);
 }
 function moonDisk(c, point, moon, starLight) {
  const fraction = clamp(moon.illuminated,0,1);
  if (fraction < .003) return;
  const radius = 13;
  const light = '#F6EAC9';
  if (starLight > .1) {
   c.globalAlpha = .23 * starLight;
   circle(c,point.x,point.y,radius,'#51627A');
   c.globalAlpha = 1;
  }
  if (fraction > .997) {
   circle(c,point.x,point.y,radius,light);
   return;
  }
  // A projected sphere: for each chord, the terminator's x coordinate
  // is (1 - 2f) times the limb's. Rotate its bright side toward the Sun.
  const angle = moon.limbAngle * radians;
  const right = Math.sin(angle), up = -Math.cos(angle);
  const edge = [];
  function edgePoint(i, scale) {
   const t = -Math.PI/2 + Math.PI*i/20;
   const x = scale*Math.cos(t)*radius, y = Math.sin(t)*radius;
   return [point.x+right*x-up*y, point.y+up*x+right*y];
  }
  for (let i=0;i<=20;i++) edge.push(edgePoint(i,1));
  for (let i=20;i>=0;i--) edge.push(edgePoint(i,1-2*fraction));
  poly(c,edge,light);
 }
 function stars(c, view, time, amount) {
  if (amount < .005) return;
  c.fillStyle = '#DCE6EE';
  for (let group=0;group<3;group++) {
   c.globalAlpha = amount * (.45 + .12*Math.sin(time*.34+group*2));
   for (let i=group;i<44;i+=3) {
    const x = 8 + (i*97 + view.bearing*7)%463, y = 6+(i*59+view.bearing)%169;
    c.fillRect(x,y,i%8 === 0 ? 2 : 1,1);
    if (i%13 === 0) c.fillRect(x+.5,y-1,1,3);
   }
  }
  const age = time%19;
  if (age > 0 && age < 1.6) {
   const x=92+age*100,y=63+age*34;
   c.globalAlpha=amount*Math.sin(Math.PI*age/1.6)*.8;
   line(c,x,y,x-32,y-11,'#D0DDF0');
   rect(c,x,y,2,2,'#F0EADB');
  }
  c.globalAlpha=1;
 }
 // Draw precipitation in two batched paths so even the densest landscape
 // stays within the sandbox's 700-command frame budget.
 function precipitation(c, condition, time) {
  const snow = condition === 'snow';
  if (!snow && condition !== 'rain') return;
  c.save();
  c.fillStyle = '#EAF1F4'; c.strokeStyle = '#BDCED9'; c.lineWidth = 1;
  for (let layer=0;layer<2;layer++) {
   c.globalAlpha = (snow ? .55 : .28) + layer*.17;
   c.beginPath();
   for (let i=0;i<12;i++) {
    const speed = snow ? 12+layer*9 : 128+layer*48;
    const y = (i*71 + time*speed + layer*113)%352 - 16;
    const drift = snow ? Math.sin(time*.7+i)*8 + time*4 : -time*18;
    const x = ((i*97 + layer*39 + drift)%520 + 520)%520 - 20;
    if (snow) {
     const radius = 1.2 + layer*.7;
     c.moveTo(x+radius,y); c.arc(x,y,radius,0,Math.PI*2);
    } else { c.moveTo(x,y); c.lineTo(x-3,y+10+layer*5); }
   }
   if (snow) c.fill(); else c.stroke();
  }
  c.restore();
 }
 function sky(api,s) {
  const c = api.canvas, time = s.time;
  const mode = api.settings.landscape_time || 'night';
  const direction = api.settings.landscape_direction || 'east';
  const view = views[direction] || views.east;
  const sample = api.host?.sky?.[mode];
  const weather = api.host?.weather;
  const condition = weather?.condition;
  const wet = condition === 'rain' || condition === 'snow';
  const cover = wet ? 1 : condition === 'cloudy' ? (weather.code === 2 ? .65 : 1) :
   condition === 'clear' ? (weather.code === 1 ? .2 : 0) : 0;
  const altitude = sample ? sample.sun.altitude : fallbackLight(mode,api.now);
  const twilight = clamp((altitude+14)/13,0,1), daylight = clamp((altitude+1)/17,0,1);
  const tone = (night,dusk,day) => {
   const original = mixColor(mixColor(night,dusk,twilight),day,daylight);
   return mixColor(original,mixColor(0x162230,0x6B7C87,daylight),cover*.52);
  };
  const facingSun = sample ? (1+Math.cos(bearingOffset(sample.sun.azimuth,view.bearing)*radians))/2 : .45;
  const skyTop = tone(0x0A132C,0x606784,0x4488B5);
  const skyBottom = tone(0x514D69,mixColor(0xCBB1B4,0xFFAB72,facingSun),0xE3E9D6);
  for (let step=0;step<64;step++) {
   rect(c,0,step*4,480,5,hex(mixColor(skyTop,skyBottom,step/63)));
  }

  const visibility = 1-cover;
  const starLight = clamp((-altitude-3)/9,0,1)*visibility;
  stars(c,view,time,starLight);
  const sun = skyPoint(sample?.sun,view.bearing), moon = skyPoint(sample?.moon,view.bearing);
  if (sun && visibility > 0) {
   c.globalAlpha=.10*visibility; circle(c,sun.x,sun.y,24,'#FFF2BE');
   c.globalAlpha=.17*visibility; circle(c,sun.x,sun.y,15,'#FFF2BE');
   c.globalAlpha=visibility; circle(c,sun.x,sun.y,8,'#FFF4BF');
   c.globalAlpha=1;
  }
  if (moon && visibility > 0) moonDisk(c,moon,sample.moon,starLight);

  const drift = (time*.7+view.bearing*.9)%680;
  c.globalAlpha=.16+.29*daylight;
  cloud(c,drift-150,72,125,12,hex(tone(0x8892AB,0xFFE1D5,0xF1F0DF)));
  cloud(c,(drift+320)%680-150,112,167,8,hex(tone(0x727F99,0xF8CFC3,0xDFE9E5)));
  if (cover > 0) {
   // Broad, overlapping layers keep an overcast sky legible on a small screen.
   c.globalAlpha=cover*.68;
   const cloudShade=hex(mixColor(0x354354,wet?0x87959F:0xAFBDC3,daylight));
   cloud(c,-85+(time*.6)%38,23,395,72,cloudShade);
   cloud(c,210-(time*.4)%36,57,385,73,cloudShade);
   cloud(c,-36+(time*.3)%30,109,530,54,cloudShade);
  }
  c.globalAlpha=1;
  const far = hex(tone(0x30354E,0x89758A,0x829CA3));
  const ridgeShade = hex(tone(0x252B45,0x73687E,0x688992));
  const trees = hex(tone(0x172839,0x4A5964,0x527568));
  ridge(c,view.far,far);
  for (const peak of [2,7,10]) {
   const x=peak*40, y=view.far[peak];
   poly(c,[[x,y],[x+40,view.far[peak+1]],[x+58,257],[x+18,y+24],[x+10,y+11]],ridgeShade);
  }
  if (direction === 'north') {
   const glint = hex(tone(0x515467,0xBF9E9C,0xC1D1CA));
   poly(c,[[251,156],[280,143],[300,154],[290,152],[286,155],[278,149],[269,153],[266,151]],glint);
   poly(c,[[64,189],[80,180],[92,183],[85,184],[80,182],[75,186]],glint);
  }
  ridge(c,view.near,trees);
  const waterY=256;
  const waterTop = tone(0x25354B,0xAA8B91,0x98B8B4);
  const waterBottom = tone(0x0C1C2B,0x485563,0x4D8587);
  for (let step=0;step<16;step++) rect(c,0,waterY+step*4,480,5,hex(mixColor(waterTop,waterBottom,step/15)));
  const ripple = hex(tone(0x51637A,0xCEAC9E,0xCCDBCA));
  c.globalAlpha=.42;
  for (let i=0;i<18;i++) {
   const y=259+(i*19)%57, x=(i*83+view.bearing)%463+Math.sin(time*.3+i)*2;
   rect(c,x,y,3+i%5*3,1,ripple);
  }
  c.globalAlpha=1;
  // A direct reflection belongs to the visible disk, and is hidden if
  // that disk is behind the illustrated ridgeline.
  const light = sun || (sample?.moon.illuminated > .02 ? moon : null);
  if (light && visibility > 0) {
   const k=clamp(Math.floor(light.x/40),0,11), part=clamp(light.x/40-k,0,1);
   if (light.y < view.far[k]*(1-part)+view.far[k+1]*part) {
    c.globalAlpha = visibility*(sun ? .60 : .48*sample.moon.illuminated);
    for (let i=0;i<8;i++) {
     const w=5+i*2.6;
     rect(c,light.x-w/2+Math.sin(time*.5+i)*i,259+i*6.8,w,1.2,sun?'#FFE8AB':'#D0DBDF');
    }
    c.globalAlpha=1;
   }
  }
  const bank=hex(tone(0x11232C,0x374B4C,0x416757));
  const foreground=hex(tone(0x0B1926,0x2D3B3D,0x2C5149));
  if (direction === 'north') {
   poly(c,[[0,259],[54,253],[96,258],[139,269],[70,265],[18,270],[0,269]],bank);
   for (const [x,base,size] of [[2,262,57],[20,260,44],[39,258,30],[65,259,21],[446,303,52],[473,308,88]]) pine(c,x,base,size,foreground);
   poly(c,[[400,320],[433,305],[460,302],[480,295],[480,320]],bank);
  } else if (direction === 'south') {
   // An anchored sailboat gives the open southern shore a little scale.
   const bob=Math.sin(time*.45)*.55, sail=hex(tone(0x657077,0xC5A995,0xF0E3C5));
   line(c,317,262+bob,317,243+bob,foreground);
   poly(c,[[315,245+bob],[315,260+bob],[305,260+bob]],sail);
   poly(c,[[319,250+bob],[325,260+bob],[319,260+bob]],sail);
   poly(c,[[302,262+bob],[329,262+bob],[323,265+bob],[308,265+bob]],foreground);
   poly(c,[[62,262],[82,258],[96,258],[104,256],[113,259],[129,260],[141,262]],bank);
   poly(c,[[0,320],[0,304],[31,297],[52,298],[96,309],[124,320]],foreground);
   for (const [x,h] of [[9,26],[16,20],[34,23],[46,17],[55,13]]) {
    line(c,x,303,x-3,303-h,bank,1.4);
    line(c,x-3,303-h,x-4,298-h,bank,2.7);
   }
  } else if (direction === 'west') {
   // A small timber jetty leads the eye into the sunset.
   const boards=hex(tone(0x253340,0x70554D,0x856F5A));
   poly(c,[[335,320],[408,277],[432,277],[426,320]],foreground);
   poly(c,[[335,316],[406,275],[433,275],[423,316]],boards);
   for (const [x,y,end] of [[351,307,424],[373,294,427],[390,284,430],[400,279,432]]) line(c,x,y,end,y,foreground);
   for (const [x,y,h] of [[408,279,12],[430,279,12],[372,299,17],[425,307,18]]) rect(c,x,y-h,3,h,foreground);
  } else {
   poly(c,[[0,256],[41,251],[79,253],[117,261],[157,265],[107,265],[66,261],[19,266],[0,265]],bank);
   for (const [x,base,size] of [[4,259,35],[22,255,42],[42,254,25],[61,255,16]]) pine(c,x,base,size,foreground);
   poly(c,[[390,320],[425,309],[454,307],[465,301],[480,303],[480,320]],foreground);
  }
  precipitation(c,condition,time);
  if (!sample) {
   c.save(); c.fillStyle='#101A28'; c.globalAlpha=.76; c.fillRect(83,8,314,20);
   c.globalAlpha=1; c.fillStyle='#E0E8E7'; c.font='12px sans-serif'; c.textAlign='center';
   c.fillText(api.t('landscape_no_location','Set a weather location to show the Sun and Moon'),240,22,304); c.restore();
  }
 }
 return {rain,sky};
})();

const widget={render(api){
 const scenes=['aquarium','campfire','rain','night'],selected=scenes.includes(api.settings.scene)?api.settings.scene:'aquarium';
 let s=api.active?api.state:JSON.parse(JSON.stringify(api.state));if(s.v!==1||!s.scenes)s={v:1,scenes:{},time:0,last:0,selection:selected,cycle:api.settings.cycle};
 if(s.selection!==selected||s.cycle!==api.settings.cycle){s.selection=selected;s.cycle=api.settings.cycle;s.time=0;s.last=0;}
 const dt=s.last?Math.max(0,Math.min(.25,(api.now-s.last)/1000)):0;s.last=api.now;if(api.active)s.time+=dt;
 const period=Number(api.settings.cycle)||0,index=(scenes.indexOf(selected)+(period?Math.floor(s.time/period):0))%scenes.length,scene=api.active?scenes[index]:selected;
 let state=s.scenes[scene]||{};if(s.shown!==scene){state.last=0;s.shown=scene;s.hintTime=0;}
 if(api.active)s.hintTime=(s.hintTime||0)+dt;
 // Relax is passive even though the original standalone aquarium is interactive.
 // Keep its animation/settings, but never forward taps or its feeding hint.
 const child={...api,inputs:[],state};
 if(scene==='aquarium'){child.settings={...api.settings,hint:false};AquariumView.render(child);}
 else if(scene==='campfire')CampfireView.render(child);
 else {
  state.time=(state.time||0)+(api.active?dt:0);
  (scene==='rain'?RelaxScenes.rain:RelaxScenes.sky)(child,state);
  if(api.settings.clock){const d=new Date(api.now),c=api.canvas;c.fillStyle='#D3CBBF';c.font='16px monospace';c.fillText(String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'),24,307);}
 }
 s.scenes[scene]=child.state;if(api.active||api.state.v!==1)api.state=s;
 if(scene==='aquarium'&&api.settings.clock){const d=new Date(api.now),c=api.canvas;c.fillStyle='#D3CBBF';c.font='16px monospace';c.fillText(String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'),24,307);}
 if(scene!=='campfire'){const shade=({dim:.28,normal:0,bright:0})[api.settings.brightness]||0;if(shade){api.canvas.globalAlpha=shade;api.canvas.fillStyle='#000000';api.canvas.fillRect(0,0,480,320);api.canvas.globalAlpha=1;}else if(api.settings.brightness==='bright'){api.canvas.globalAlpha=.08;api.canvas.fillStyle='#FFFFFF';api.canvas.fillRect(0,0,480,320);api.canvas.globalAlpha=1;}}
 if(api.settings.hint!==false&&(s.hintTime||0)<7){
  const c=api.canvas;c.save();c.globalAlpha=.75;c.fillStyle='#101A28';c.fillRect(116,288,248,27);c.globalAlpha=1;c.fillStyle='#D8E3E0';c.font='12px sans-serif';c.textAlign='center';c.fillText(api.t('return_hint','Tap to return to buttons'),240,307);c.restore();
 }
 const volume=({off:0,quiet:.15,normal:.3})[api.settings.sound]||0;
 if((scene==='rain'||scene==='campfire')&&volume>0&&api.active&&api.playSound)api.playSound(scene,volume);
}};
